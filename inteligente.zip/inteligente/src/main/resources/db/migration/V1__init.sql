CREATE TABLE Parking_lot (
                             ID_PARKING INT PRIMARY KEY,
                             Space_State VARCHAR(255),
                             Vehicle_ID INT,
                             Parking_lot_owner VARCHAR(255)
);

CREATE TABLE Vehicles (
                          ID_VEHICLES INT PRIMARY KEY,
                          Vehicle_Type VARCHAR(255),
                          Vehicle_plate VARCHAR(255)
);

CREATE TABLE Person (
                        ID_PERSON INT PRIMARY KEY,
                        Vehicle_Type VARCHAR(255),
                        Phone VARCHAR(255),
                        ID_Vehicles INT,
                        FOREIGN KEY (ID_Vehicles) REFERENCES Vehicles(ID_VEHICLES)
);

CREATE TABLE Device (
                        ID_DEVICE INT PRIMARY KEY,
                        SPACE_ID INT,
                        VEHICLE_ID INT,
                        ID_PLATFORM INT,
                        FOREIGN KEY (VEHICLE_ID) REFERENCES Vehicles(ID_VEHICLES)
);
