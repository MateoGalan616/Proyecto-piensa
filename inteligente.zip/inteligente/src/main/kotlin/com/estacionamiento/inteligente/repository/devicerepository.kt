package com.estacionamiento.inteligente.repository

import com.estacionamiento.inteligente.service.person
import org.springframework.stereotype.Repository

@Repository
interface devicerepository {
    fun findById(id: Long?): Module?

    companion object {
        fun findById(deviceid: Any) {

        }

        fun <deviceservice> findAll(): List<com.estacionamiento.inteligente.service.personservice> {
            TODO("Not yet implemented")
        }

        fun <Person> save(person: Person): person {

            return TODO("Provide the return value")
        }
    }

}