package com.estacionamiento.inteligente.controller

import com.estacionamiento.inteligente.model.Device
import com.estacionamiento.inteligente.repository.devicerepository
import com.estacionamiento.inteligente.service.deviceservice
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/device")
@CrossOrigin(methods = [RequestMethod.GET, RequestMethod.POST, RequestMethod.PATCH, RequestMethod.PUT, RequestMethod.DELETE])
class devicecontroller {
    @Autowired
    lateinit var devicecontroller: devicecontroller
    @GetMapping
    fun list (): List<devicerepository> {
        return deviceservice.list<devicerepository>()
    }
    @PostMapping
    fun save (@RequestBody device: Device): ResponseEntity<device> {
        return ResponseEntity(deviceservice.save(device()), HttpStatus.OK)
    }
    @PutMapping
    fun update (@RequestBody device: Device): ResponseEntity<device> {
        return ResponseEntity(deviceservice.update(device), HttpStatus.OK)
    }
    @PatchMapping
    fun updateName (@RequestBody device: Device): ResponseEntity<devicecontroller> {
        return ResponseEntity(deviceservice.update(devicecontroller()), HttpStatus.OK)
    }
}

class device {

}
