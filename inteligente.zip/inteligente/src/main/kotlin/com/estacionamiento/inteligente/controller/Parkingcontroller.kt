package com.estacionamiento.inteligente.controller

import com.estacionamiento.inteligente.model.Parking_lot
import com.estacionamiento.inteligente.service.Parkingservice
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/parking")
@CrossOrigin(methods = [RequestMethod.GET, RequestMethod.POST, RequestMethod.PATCH, RequestMethod.PUT, RequestMethod.DELETE])
class Parkingcontroller {
    @Autowired
    lateinit var parkingcontroller: Parkingcontroller
    @GetMapping
    fun list ():List <parking>{
        return Parkingservice.list()
    }
    @PostMapping
    fun save (@RequestBody Parking:Parking_lot): ResponseEntity<Parking_lot> {
        return ResponseEntity(Parkingservice.save(Parking()), HttpStatus.OK)
    }
    @PutMapping
    fun update (@RequestBody Parking: Parking_lot): ResponseEntity<Parking_lot> {
        return ResponseEntity(Parkingservice.update(Parking), HttpStatus.OK)
    }
    @PatchMapping
    fun updateName (@RequestBody Parking: Parking_lot): ResponseEntity<Parking_lot> {
        return ResponseEntity(Parkingservice.update(Parking()), HttpStatus.OK)
    }

}

class parking {

}
