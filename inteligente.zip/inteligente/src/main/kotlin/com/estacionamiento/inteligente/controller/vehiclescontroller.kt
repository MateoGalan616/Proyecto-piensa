package com.estacionamiento.inteligente.controller

import com.estacionamiento.inteligente.repository.vehiclesrepository
import com.estacionamiento.inteligente.service.person
import com.estacionamiento.inteligente.service.vehiclesservice
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/vehicles")
@CrossOrigin(methods = [RequestMethod.GET, RequestMethod.POST, RequestMethod.PATCH, RequestMethod.PUT, RequestMethod.DELETE])
class vehiclescontroller {
    @Autowired
    lateinit var vehiclescontroller: vehiclescontroller
    @GetMapping
    fun list ():List <vehiclescontroller>{
        return vehiclesservice.list<vehiclesrepository>()
    }
    @PostMapping
    fun save (@RequestBody vehicles: vehiclescontroller): ResponseEntity<vehiclescontroller> {
        return ResponseEntity(vehiclesservice.save(person()), HttpStatus.OK)
    }
    @PutMapping
    fun update (@RequestBody vehicles: vehiclescontroller): ResponseEntity<vehiclescontroller> {
        return ResponseEntity(vehiclesservice.update(vehicles), HttpStatus.OK)
    }
    @PatchMapping
    fun updateName (@RequestBody vehicles: vehiclescontroller): ResponseEntity<vehiclescontroller> {
        return ResponseEntity(vehiclesservice.update(vehiclescontroller()), HttpStatus.OK)
    }
}