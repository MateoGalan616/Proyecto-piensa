package com.estacionamiento.inteligente.repository

import com.estacionamiento.inteligente.service.person
import com.estacionamiento.inteligente.service.vehicles
import org.springframework.stereotype.Repository

@Repository
interface vehiclesrepository {
    fun findById(id: Long?): Module?
    abstract fun <vehicles> findAll(): List<vehicles>
    fun <Vehicles> save(vehicles: Vehicles): vehicles {

        return TODO("Provide the return value")
    }

    companion object {
        fun findById(vehiclesid: Any) {

        }

        fun <vehiclesservice> findAll(): List<com.estacionamiento.inteligente.service.personservice> {
            TODO("Not yet implemented")
        }

        fun <Person> save(person: Person): person {

            return TODO("Provide the return value")
        }
    }
}