package com.estacionamiento.inteligente.model

import jakarta.persistence.*


    @Entity
    @Table(name="Parkin_lot")
    class Parking_lot {
        operator fun invoke(): Any {
            TODO("Not yet implemented")
        }

        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Id
        @Column(updatable = false)
        var id: Long? = null
        var description: String?
            get() = null
            set(value) = TODO()
        var fullname: String?= null
}