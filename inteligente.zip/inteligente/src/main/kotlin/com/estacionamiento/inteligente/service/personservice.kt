package com.estacionamiento.inteligente.service

import com.estacionamiento.inteligente.model.Person
import com.estacionamiento.inteligente.repository.ParkingRepository
import com.estacionamiento.inteligente.repository.personrepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.util.MultiValueMap
import org.springframework.web.server.ResponseStatusException

@Service
class personservice {
    @Autowired
    lateinit var personservice: personservice

    fun list(): List<personservice> {
        return personservice.findAll()
    }

    private fun findAll(): List<personservice> {
        TODO("Not yet implemented")
    }

    fun save(person:Person): person {
        try {
            return personrepository.save(person)
        } catch (ex: Exception) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, ex.message)
        }
    }

    fun update(person:Person): person {
        try {
            person.id?.let { ParkingRepository.findById(it) }
                ?: throw Exception("ID no existe")

            return personrepository.save(person)
        } catch (ex: Exception) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, ex.message)
        }
    }

    companion object {
        fun <parking> list(): List<parking> {

            return TODO("Provide the return value")
        }

        fun save(parking: Any): MultiValueMap<String, String> {

            return TODO("Provide the return value")
        }

        fun update(parking: Any): MultiValueMap<String, String> {

            return TODO("Provide the return value")
        }
    }
}

class person {

}
