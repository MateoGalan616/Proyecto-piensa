package com.estacionamiento.inteligente

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class InteligenteApplication

fun main(args: Array<String>) {
	runApplication<InteligenteApplication>(*args)
}
