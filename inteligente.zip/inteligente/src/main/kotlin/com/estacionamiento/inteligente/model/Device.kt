package com.estacionamiento.inteligente.model

import jakarta.persistence.*
    @Entity
    @Table(name="Device")
    class Device {
        operator fun invoke(): Any {
            TODO("Not yet implemented")
        }

        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Id
        @Column(updatable = false)
        var id: Long? = null
        var description: String? = null
        var fullname: String?= null
}
