package com.estacionamiento.inteligente.repository

import com.estacionamiento.inteligente.service.person
import org.springframework.stereotype.Repository

@Repository
interface personrepository {
    fun findById(id: Long?): Module?

    companion object {
        fun findById(personaid: Any) {

        }

        fun <personservice> findAll(): List<com.estacionamiento.inteligente.service.personservice> {
            TODO("Not yet implemented")
        }

        fun <Person> save(person: Person): person {

            return TODO("Provide the return value")
        }
    }

}