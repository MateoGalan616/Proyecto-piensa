package com.estacionamiento.inteligente.model

import jakarta.persistence.*

@Entity
@Table(name="Vehicles")
class Vehicles {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(updatable = false)
    var id: Long? = null
    var description: String? = null
    var fullname: String?= null
}