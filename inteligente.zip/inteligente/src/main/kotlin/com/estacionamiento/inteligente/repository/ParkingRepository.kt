package com.estacionamiento.inteligente.repository

import com.estacionamiento.inteligente.model.Parking_lot
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface ParkingRepository : JpaRepository<Parking_lot, Long?> {
    fun findById(id: Long?): Module?

    companion object {
        fun findById(Parkingid: Any) {

        }
    }
}