package com.estacionamiento.inteligente.service

import com.estacionamiento.inteligente.model.Parking_lot
import com.estacionamiento.inteligente.repository.ParkingRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.util.MultiValueMap
import org.springframework.web.server.ResponseStatusException
@Service
class deviceservice {
    @Autowired
    lateinit var ParkingRepository: ParkingRepository

    fun list(): List<Parking_lot> {
        return ParkingRepository.findAll()
    }

    fun save(Parking: Parking_lot): Parking_lot {
        try {
            return ParkingRepository.save(Parking)
        } catch (ex: Exception) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, ex.message)
        }
    }

    fun update(Parking: Parking_lot): Parking_lot {
        try {
            ParkingRepository.findById(Parking.id)
                ?: throw Exception("ID no existe")

            return ParkingRepository.save(Parking)
        } catch (ex: Exception) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, ex.message)
        }
    }

    companion object {
        fun <parking> list(): List<parking> {

            return TODO("Provide the return value")
        }

        fun save(parking: Any): MultiValueMap<String, String> {

            return TODO("Provide the return value")
        }

        fun update(parking: Any): MultiValueMap<String, String> {

            return TODO("Provide the return value")
        }
    }
}