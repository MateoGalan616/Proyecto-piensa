package com.estacionamiento.inteligente.service

import com.estacionamiento.inteligente.model.Vehicles
import com.estacionamiento.inteligente.repository.vehiclesrepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.util.MultiValueMap
import org.springframework.web.server.ResponseStatusException

@Service
class vehiclesservice {
    @Autowired
    lateinit var vehiclesrepository: vehiclesrepository

    fun list(): List<vehicles> {
        return vehiclesrepository.findAll()
    }

    fun save(vehicles: Vehicles): vehicles {
        try {
            return vehiclesrepository.save(vehicles)
        } catch (ex: Exception) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, ex.message)
        }
    }

    fun update(vehicles: Vehicles):vehicles {
        try {
            vehiclesrepository.findById(vehicles.id)
                ?: throw Exception("ID no existe")

            return vehiclesrepository.save(vehicles)
        } catch (ex: Exception) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, ex.message)
        }
    }

    companion object {
        fun <parking> list(): List<parking> {

            return TODO("Provide the return value")
        }

        fun save(parking: Any): MultiValueMap<String, String> {

            return TODO("Provide the return value")
        }

        fun update(parking: Any): MultiValueMap<String, String> {

            return TODO("Provide the return value")
        }
    }
}

class vehicles {

}
