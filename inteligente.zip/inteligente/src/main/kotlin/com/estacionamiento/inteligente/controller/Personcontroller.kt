package com.estacionamiento.inteligente.controller

import com.estacionamiento.inteligente.model.Parking_lot
import com.estacionamiento.inteligente.model.Person
import com.estacionamiento.inteligente.service.person
import com.estacionamiento.inteligente.service.personservice
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/person")
@CrossOrigin(methods = [RequestMethod.GET, RequestMethod.POST, RequestMethod.PATCH, RequestMethod.PUT, RequestMethod.DELETE])
class Personcontroller {
    @Autowired
    lateinit var personcontroller: Personcontroller
    @GetMapping
    fun list ():List <person>{
        return personservice.list()
    }
    @PostMapping
    fun save (@RequestBody person:person): ResponseEntity<Parking_lot> {
        return ResponseEntity(personservice.save(person()), HttpStatus.OK)
    }
    @PutMapping
    fun update (@RequestBody person:person): ResponseEntity<Parking_lot> {
        return ResponseEntity(personservice.update(person), HttpStatus.OK)
    }
    @PatchMapping
    fun updateName (@RequestBody person: Person): ResponseEntity<person> {
        return ResponseEntity(personservice.update(person()), HttpStatus.OK)
    }
}